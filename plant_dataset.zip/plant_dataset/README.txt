#############################################
####Tracheophyte DATASET


The dataset of 644 tracheophytes obtained from Barba-Montoya et al. 2018.

Barba‐Montoya, J., Dos Reis, M., Schneider, H., Donoghue, P.C. and Yang, Z., 2018. Constraining uncertainty in the timescale of angiosperm evolution and the veracity of a Cretaceous Terrestrial Revolution. New Phytologist, 218(2), pp.819-834.


From the given dataset, there are three alignment partitions (See table 2 in above cited paper).

Partition 1 - Plastid 1st and 2nd codon position
Partition 2 - Mitochondrial 1st and 2nd codon position
Partition 3 - Nuclear RNA


The ".phy" file represents the alignment files, and ".tree" files are rerooted trees for each partition, and we tested bayesian model selection with
(1) no calibrations - t1 ~ 'B(0.999,1.001)'  ,and 
(2) narrow gamma-density calibration - t1 ~ G(1000,1000). The files in the pattern 'partitionNUMB ER_gam1000.trees' are the tree files used for the analysis. Also have enclosed the ".ctl" files for each likelihood approximate method.

